# No JavaScript interfaces are exposed, so no special keep rules are required.
# Add project-specific ProGuard rules here if you add libraries later.
