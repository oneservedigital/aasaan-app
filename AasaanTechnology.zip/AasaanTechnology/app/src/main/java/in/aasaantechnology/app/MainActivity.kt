package `in`.aasaantechnology.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.DownloadManager
import android.content.ActivityNotFoundException
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.net.http.SslError
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.View
import android.webkit.CookieManager
import android.webkit.DownloadListener
import android.webkit.PermissionRequest
import android.webkit.RenderProcessGoneDetail
import android.webkit.SslErrorHandler
import android.webkit.URLUtil
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.core.view.isVisible
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.progressindicator.LinearProgressIndicator
import java.io.File

class MainActivity : AppCompatActivity() {

    companion object {
        private const val HOME_URL = "https://www.aasaantechnology.in/"

        /** Your own domain (and subdomains). Camera/mic access is only granted to these. */
        private const val OWN_DOMAIN = "aasaantechnology.in"

        /**
         * Hosts that open INSIDE the app. Any other https link opens in the browser / matching app.
         * Add payment gateways or other domains your site must stay inside of here.
         */
        private val IN_APP_HOSTS = listOf(
            OWN_DOMAIN,
            "script.google.com",
            "script.googleusercontent.com",
            "docs.google.com",
            "forms.gle"
        )
    }

    private data class PendingDownload(
        val url: String,
        val userAgent: String?,
        val contentDisposition: String?,
        val mimeType: String?
    )

    private lateinit var root: View
    private lateinit var webView: WebView
    private lateinit var swipeRefresh: SwipeRefreshLayout
    private lateinit var progressBar: LinearProgressIndicator
    private lateinit var offlineView: View
    private lateinit var offlineTitle: TextView
    private lateinit var offlineMessage: TextView
    private lateinit var loadingView: View

    private var lastFailedUrl: String? = null

    // File upload state
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private var cameraPhotoUri: Uri? = null
    private var cameraFile: File? = null
    private var pendingChooserParams: WebChromeClient.FileChooserParams? = null

    // Web camera/mic permission state
    private var pendingPermissionRequest: PermissionRequest? = null

    // Download state
    private var pendingDownload: PendingDownload? = null
    private val pdfDownloadIds = mutableSetOf<Long>()

    // ---------------------------------------------------------------- launchers

    private val fileChooserLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val callback = fileCallback ?: return@registerForActivityResult
            fileCallback = null
            var uris: Array<Uri>? = null
            if (result.resultCode == RESULT_OK) {
                uris = WebChromeClient.FileChooserParams.parseResult(result.resultCode, result.data)
                if (uris == null) {
                    // Photo taken with the camera (written to our FileProvider file)
                    val photo = cameraPhotoUri
                    val file = cameraFile
                    if (photo != null && file != null && file.length() > 0) uris = arrayOf(photo)
                }
            }
            cameraPhotoUri = null
            callback.onReceiveValue(uris)
        }

    private val cameraPermissionForChooser =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            val params = pendingChooserParams ?: return@registerForActivityResult
            pendingChooserParams = null
            launchFileChooser(params, includeCamera = granted)
        }

    private val webPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            val request = pendingPermissionRequest ?: return@registerForActivityResult
            pendingPermissionRequest = null
            grantWebPermissions(request)
        }

    private val storagePermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            val download = pendingDownload
            pendingDownload = null
            if (granted && download != null) startDownload(download) else toast(R.string.storage_permission_needed)
        }

    /** Opens downloaded PDFs automatically so users can view them. */
    private val downloadReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val id = intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1L)
            if (!pdfDownloadIds.remove(id)) return
            val dm = getSystemService(DOWNLOAD_SERVICE) as DownloadManager
            dm.query(DownloadManager.Query().setFilterById(id))?.use { cursor ->
                if (!cursor.moveToFirst()) return
                val status = cursor.getInt(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))
                if (status != DownloadManager.STATUS_SUCCESSFUL) return
                val uri = dm.getUriForDownloadedFile(id) ?: return
                val view = Intent(Intent.ACTION_VIEW)
                    .setDataAndType(uri, "application/pdf")
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
                try {
                    startActivity(view)
                } catch (e: ActivityNotFoundException) {
                    toast(R.string.download_saved)
                }
            }
        }
    }

    // ---------------------------------------------------------------- lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)

        WindowCompat.setDecorFitsSystemWindows(window, false)
        setContentView(R.layout.activity_main)

        root = findViewById(R.id.root)
        webView = findViewById(R.id.webView)
        swipeRefresh = findViewById(R.id.swipeRefresh)
        progressBar = findViewById(R.id.progressBar)
        offlineView = findViewById(R.id.offlineView)
        offlineTitle = findViewById(R.id.offlineTitle)
        offlineMessage = findViewById(R.id.offlineMessage)
        loadingView = findViewById(R.id.loadingView)

        // Keep the website clear of the status bar / navigation bar / keyboard
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val bars = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or
                    WindowInsetsCompat.Type.displayCutout() or
                    WindowInsetsCompat.Type.ime()
            )
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            WindowInsetsCompat.CONSUMED
        }
        WindowInsetsControllerCompat(window, root).apply {
            isAppearanceLightStatusBars = true
            isAppearanceLightNavigationBars = true
        }

        configureWebView()

        swipeRefresh.setColorSchemeResources(R.color.brand_blue)
        swipeRefresh.setOnChildScrollUpCallback { _, _ -> webView.scrollY > 0 }
        swipeRefresh.setOnRefreshListener { webView.reload() }

        findViewById<View>(R.id.retryButton).setOnClickListener {
            hideOffline()
            progressBar.isVisible = true
            webView.loadUrl(lastFailedUrl ?: HOME_URL)
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (webView.canGoBack()) {
                    hideOffline()
                    webView.goBack()
                } else {
                    confirmExit()
                }
            }
        })

        ContextCompat.registerReceiver(
            this,
            downloadReceiver,
            IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE),
            ContextCompat.RECEIVER_EXPORTED
        )

        if (savedInstanceState == null || webView.restoreState(savedInstanceState) == null) {
            webView.loadUrl(HOME_URL)
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        webView.saveState(outState)
    }

    override fun onResume() {
        super.onResume()
        webView.onResume()
    }

    override fun onPause() {
        webView.onPause()
        CookieManager.getInstance().flush()
        super.onPause()
    }

    override fun onDestroy() {
        unregisterReceiver(downloadReceiver)
        fileCallback?.onReceiveValue(null)
        fileCallback = null
        pendingPermissionRequest?.deny()
        pendingPermissionRequest = null
        swipeRefresh.removeView(webView)
        webView.stopLoading()
        webView.destroy()
        super.onDestroy()
    }

    // ---------------------------------------------------------------- WebView setup

    @SuppressLint("SetJavaScriptEnabled")
    private fun configureWebView() {
        if (applicationInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE != 0) {
            WebView.setWebContentsDebuggingEnabled(true)
        }

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            javaScriptCanOpenWindowsAutomatically = true
            setSupportMultipleWindows(false) // window.open() loads in this WebView
            useWideViewPort = true
            loadWithOverviewMode = true
            setSupportZoom(true)
            builtInZoomControls = true
            displayZoomControls = false

            // Security hardening
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            allowFileAccess = false
            allowContentAccess = false
            setGeolocationEnabled(false)
        }

        CookieManager.getInstance().apply {
            setAcceptCookie(true)
            // Needed for embedded Google Apps Script / Forms iframes
            setAcceptThirdPartyCookies(webView, true)
        }

        // NOTE: no addJavascriptInterface() on purpose - nothing from Android is exposed to the page.

        webView.webViewClient = AppWebViewClient()
        webView.webChromeClient = AppWebChromeClient()
        webView.setDownloadListener(DownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
            handleDownload(PendingDownload(url, userAgent, contentDisposition, mimeType))
        })
    }

    private inner class AppWebViewClient : WebViewClient() {

        override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
            return handleUrl(request.url, request.isForMainFrame)
        }

        override fun onPageStarted(view: WebView, url: String?, favicon: android.graphics.Bitmap?) {
            progressBar.isVisible = true
        }

        override fun onPageFinished(view: WebView, url: String?) {
            swipeRefresh.isRefreshing = false
            progressBar.isVisible = false
            if (!offlineView.isVisible) hideLoadingOverlay()
            CookieManager.getInstance().flush()
        }

        override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
            if (request.isForMainFrame) {
                showOffline(request.url.toString(), R.string.no_internet_title, R.string.no_internet_message)
            }
        }

        // Never proceed past SSL errors.
        override fun onReceivedSslError(view: WebView, handler: SslErrorHandler, error: SslError) {
            handler.cancel()
            showOffline(error.url, R.string.ssl_error_title, R.string.ssl_error_message)
        }

        override fun onRenderProcessGone(view: WebView, detail: RenderProcessGoneDetail): Boolean {
            recreate()
            return true
        }
    }

    private inner class AppWebChromeClient : WebChromeClient() {

        override fun onProgressChanged(view: WebView, newProgress: Int) {
            progressBar.setProgressCompat(newProgress, true)
            progressBar.isVisible = newProgress < 100
        }

        override fun onShowFileChooser(
            webView: WebView,
            filePathCallback: ValueCallback<Array<Uri>>,
            fileChooserParams: FileChooserParams
        ): Boolean {
            fileCallback?.onReceiveValue(null)
            fileCallback = filePathCallback

            val types = fileChooserParams.acceptTypes
            val acceptsImages = types.isEmpty() ||
                types.any { it.isBlank() || it.startsWith("image") || it == "*/*" }

            val cameraGranted = ContextCompat.checkSelfPermission(
                this@MainActivity, Manifest.permission.CAMERA
            ) == PackageManager.PERMISSION_GRANTED

            if (acceptsImages && !cameraGranted) {
                pendingChooserParams = fileChooserParams
                cameraPermissionForChooser.launch(Manifest.permission.CAMERA)
            } else {
                launchFileChooser(fileChooserParams, includeCamera = acceptsImages)
            }
            return true
        }

        // Website asks for camera / microphone (getUserMedia)
        override fun onPermissionRequest(request: PermissionRequest) {
            runOnUiThread {
                val host = request.origin.host?.lowercase()
                val trusted = host != null && (host == OWN_DOMAIN || host.endsWith(".$OWN_DOMAIN"))
                if (!trusted) {
                    request.deny()
                    return@runOnUiThread
                }
                val needed = mutableListOf<String>()
                for (resource in request.resources) {
                    when (resource) {
                        PermissionRequest.RESOURCE_VIDEO_CAPTURE -> needed.add(Manifest.permission.CAMERA)
                        PermissionRequest.RESOURCE_AUDIO_CAPTURE -> needed.add(Manifest.permission.RECORD_AUDIO)
                    }
                }
                if (needed.isEmpty()) {
                    request.deny()
                    return@runOnUiThread
                }
                val missing = needed.filter {
                    ContextCompat.checkSelfPermission(this@MainActivity, it) != PackageManager.PERMISSION_GRANTED
                }
                if (missing.isEmpty()) {
                    grantWebPermissions(request)
                } else {
                    pendingPermissionRequest?.deny()
                    pendingPermissionRequest = request
                    webPermissionLauncher.launch(missing.toTypedArray())
                }
            }
        }

        override fun onPermissionRequestCanceled(request: PermissionRequest) {
            if (pendingPermissionRequest == request) pendingPermissionRequest = null
        }
    }

    // ---------------------------------------------------------------- URL handling

    private fun isInAppHost(host: String?): Boolean {
        val h = host?.lowercase() ?: return false
        return IN_APP_HOSTS.any { h == it || h.endsWith(".$it") }
    }

    /** Returns true if the navigation was handled here (WebView must not load it). */
    private fun handleUrl(uri: Uri, isMainFrame: Boolean): Boolean {
        return when (uri.scheme?.lowercase()) {
            "https" -> {
                if (!isMainFrame || isInAppHost(uri.host)) {
                    false
                } else {
                    openExternal(uri)
                    true
                }
            }
            "http" -> {
                // HTTPS only: upgrade, never load cleartext.
                val secure = uri.buildUpon().scheme("https").build()
                if (isInAppHost(uri.host)) webView.loadUrl(secure.toString()) else openExternal(secure)
                true
            }
            "about", "blob", "data", "javascript" -> false
            "intent" -> {
                openIntentUri(uri)
                true
            }
            // tel:, mailto:, sms:, upi:, whatsapp:, geo:, market:, phonepe:, paytmmp:, gpay: ...
            else -> {
                openExternal(uri)
                true
            }
        }
    }

    private fun openExternal(uri: Uri) {
        try {
            val intent = Intent(Intent.ACTION_VIEW, uri).addCategory(Intent.CATEGORY_BROWSABLE)
            startActivity(intent)
        } catch (e: Exception) {
            toast(R.string.no_app_found)
        }
    }

    private fun openIntentUri(uri: Uri) {
        try {
            val intent = Intent.parseUri(uri.toString(), Intent.URI_INTENT_SCHEME).apply {
                addCategory(Intent.CATEGORY_BROWSABLE)
                component = null
                selector = null
            }
            try {
                startActivity(intent)
            } catch (e: ActivityNotFoundException) {
                val fallback = intent.getStringExtra("browser_fallback_url")
                if (fallback != null && fallback.startsWith("https://")) {
                    webView.loadUrl(fallback)
                } else {
                    toast(R.string.no_app_found)
                }
            }
        } catch (e: Exception) {
            toast(R.string.no_app_found)
        }
    }

    // ---------------------------------------------------------------- file chooser

    private fun launchFileChooser(params: WebChromeClient.FileChooserParams, includeCamera: Boolean) {
        try {
            val chooser = Intent.createChooser(params.createIntent(), getString(R.string.select_file))
            if (includeCamera) {
                createCameraIntent()?.let {
                    chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, arrayOf(it))
                }
            }
            fileChooserLauncher.launch(chooser)
        } catch (e: Exception) {
            fileCallback?.onReceiveValue(null)
            fileCallback = null
            toast(R.string.file_picker_failed)
        }
    }

    private fun createCameraIntent(): Intent? = try {
        val dir = File(cacheDir, "uploads").apply { mkdirs() }
        val file = File.createTempFile("IMG_", ".jpg", dir)
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
        cameraFile = file
        cameraPhotoUri = uri
        Intent(MediaStore.ACTION_IMAGE_CAPTURE)
            .putExtra(MediaStore.EXTRA_OUTPUT, uri)
            .addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_READ_URI_PERMISSION)
    } catch (e: Exception) {
        null
    }

    private fun grantWebPermissions(request: PermissionRequest) {
        val allowed = mutableListOf<String>()
        for (resource in request.resources) {
            when (resource) {
                PermissionRequest.RESOURCE_VIDEO_CAPTURE ->
                    if (hasPermission(Manifest.permission.CAMERA)) allowed.add(resource)
                PermissionRequest.RESOURCE_AUDIO_CAPTURE ->
                    if (hasPermission(Manifest.permission.RECORD_AUDIO)) allowed.add(resource)
            }
        }
        if (allowed.isEmpty()) request.deny() else request.grant(allowed.toTypedArray())
    }

    private fun hasPermission(permission: String) =
        ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED

    // ---------------------------------------------------------------- downloads

    private fun handleDownload(download: PendingDownload) {
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P &&
            !hasPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        ) {
            pendingDownload = download
            storagePermissionLauncher.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
            return
        }
        startDownload(download)
    }

    private fun startDownload(download: PendingDownload) {
        val uri = Uri.parse(download.url)
        if (!"https".equals(uri.scheme, ignoreCase = true)) {
            toast(R.string.download_failed)
            return
        }
        try {
            val fileName = URLUtil.guessFileName(download.url, download.contentDisposition, download.mimeType)
            val request = DownloadManager.Request(uri).apply {
                download.mimeType?.let { setMimeType(it) }
                CookieManager.getInstance().getCookie(download.url)?.let { addRequestHeader("Cookie", it) }
                download.userAgent?.let { addRequestHeader("User-Agent", it) }
                setTitle(fileName)
                setDescription(getString(R.string.downloading))
                setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName)
            }
            val dm = getSystemService(DOWNLOAD_SERVICE) as DownloadManager
            val id = dm.enqueue(request)
            val isPdf = "application/pdf".equals(download.mimeType, ignoreCase = true) ||
                fileName.endsWith(".pdf", ignoreCase = true)
            if (isPdf) pdfDownloadIds.add(id)
            toast(R.string.download_started)
        } catch (e: Exception) {
            toast(R.string.download_failed)
        }
    }

    // ---------------------------------------------------------------- UI helpers

    private fun showOffline(failedUrl: String?, titleRes: Int, messageRes: Int) {
        lastFailedUrl = failedUrl
        offlineTitle.setText(titleRes)
        offlineMessage.setText(messageRes)
        offlineView.isVisible = true
        swipeRefresh.isVisible = false
        swipeRefresh.isRefreshing = false
        progressBar.isVisible = false
        loadingView.isVisible = false
    }

    private fun hideOffline() {
        offlineView.isVisible = false
        swipeRefresh.isVisible = true
    }

    private fun hideLoadingOverlay() {
        if (!loadingView.isVisible) return
        loadingView.animate()
            .alpha(0f)
            .setDuration(250)
            .withEndAction { loadingView.isVisible = false }
            .start()
    }

    private fun confirmExit() {
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.exit_title)
            .setMessage(R.string.exit_message)
            .setPositiveButton(R.string.exit) { _, _ -> finish() }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun toast(resId: Int) = Toast.makeText(this, resId, Toast.LENGTH_SHORT).show()
}
